package com.example.demo.metier;

import org.springframework.data.domain.Page;


import com.example.demo.entities.Note;
import com.example.demo.entities.Personne;

public interface INoteMetier {
	
	public void AjouterNote(String objet, String description, Personne personne, String LienFichier);
	public void AjouterNote(String objet, String description, Long matricule, String LienFichier);
	public Page<Note> ListsExam(String objet, int page, int size);
	public Page<Note> ListsTousLesNotes(int page, int size);
	public Page<Note> ListsNotesRecherche(String objet, int page, int size);

	


}
