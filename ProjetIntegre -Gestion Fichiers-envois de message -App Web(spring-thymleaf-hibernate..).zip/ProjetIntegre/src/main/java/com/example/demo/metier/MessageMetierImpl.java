package com.example.demo.metier;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.MessageRepository;
import com.example.demo.dao.PersonneRepository;
import com.example.demo.entities.Message;
import com.example.demo.entities.Personne;
@Service
@Transactional
public class MessageMetierImpl implements IMessageMetier {
	@Autowired
	private MessageRepository messageRepository;
	@Autowired
	private PersonneRepository personneRepository;
	
	
	@Override
	public void envoyerMessage(Long matricule1, Long matricule2, String objet, String message) {
		Personne p1=personneRepository.findOne(matricule1);
		Personne p2=personneRepository.findOne(matricule2);
		Message m=new Message(objet,message,p1,p2,new Date());
		messageRepository.save(m);

	}
	
	@Override
	public void envoyerMessage(Personne p1, Personne p2, String objet, String message) {
		Message m=new Message(objet,message,p1,p2,new Date());
		messageRepository.save(m);

	}

	@Override
	public Page<Message> listMessageEnvoyes(Long matricule, int page, int size) {
		return messageRepository.listMessagesenvoyes(matricule,new PageRequest(page, size));
	}

	@Override
	public Page<Message> listMessageRecus(Long matricule, int page, int size) {
		return messageRepository.listMessagesrecus(matricule,new PageRequest(page, size));
	}
	
	
}
