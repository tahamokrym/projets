package com.example.demo;

import java.io.File;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.dao.*;
import com.example.demo.entities.*;
import com.example.demo.metier.*;
import com.example.demo.web.NoteController;

@SpringBootApplication

public class ProjetIntegreApplication implements CommandLineRunner {
	

	

	public static void main(String[] args) {
		
		SpringApplication.run(ProjetIntegreApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		
	}

}
