package com.example.demo.entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Message implements Serializable{
	
	 @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String Objet;
	private String message;
	@ManyToOne
	private Personne expediteur;
	@ManyToOne
	private Personne destinataire;

	private Date date;
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Message(String objet, String message, Personne expediteur, Personne destinataire, Date date) {
		super();
		Objet = objet;
		this.message = message;
		this.expediteur = expediteur;
		this.destinataire = destinataire;
		this.date = date;
	}


	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getObjet() {
		return Objet;
	}
	public void setObjet(String objet) {
		Objet = objet;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

	public Personne getExpediteur() {
		return expediteur;
	}
	public void setExpediteur(Personne expediteur) {
		this.expediteur = expediteur;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Personne getDestinataire() {
		return destinataire;
	}
	public void setDestinataire(Personne destinataire) {
		this.destinataire = destinataire;
	}
	
	
	
}
