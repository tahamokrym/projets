package com.example.demo.entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
@Entity
public class Personne implements Serializable{
	
	@Id
	private Long matricule;
	private String nom;
	private String prenom;
	private String username;
	private long telephone;
	private String email;
	private String status;
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "expediteur")
	private Collection<Message> messagesenvoyes;
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "destinataire")
	private Collection<Message> messagesrecus;
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "personne")
	private Collection<Note> notes;
	public Personne() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Personne(Long matricule, String nom, String prenom, String username, String password, long telephone,
			String email, String status) {
		super();
		this.matricule = matricule;
		this.nom = nom;
		this.prenom = prenom;
		this.username = username;
		this.telephone = telephone;
		this.email = email;
		this.status = status;
	}
	public Long getMatricule() {
		return matricule;
	}
	public void setMatricule(Long matricule) {
		this.matricule = matricule;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	public long getTelephone() {
		return telephone;
	}
	public void setTelephone(long telephone) {
		this.telephone = telephone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Collection<Message> getMessagesenvoyes() {
		return messagesenvoyes;
	}
	public void setMessagesenvoyes(Collection<Message> messagesenvoyes) {
		this.messagesenvoyes = messagesenvoyes;
	}
	public Collection<Message> getMessagesrecus() {
		return messagesrecus;
	}
	public void setMessagesrecus(Collection<Message> messagesrecus) {
		this.messagesrecus = messagesrecus;
	}
	public Collection<Note> getNotes() {
		return notes;
	}
	public void setNotes(Collection<Note> notes) {
		this.notes = notes;
	}
	
	
	

}


