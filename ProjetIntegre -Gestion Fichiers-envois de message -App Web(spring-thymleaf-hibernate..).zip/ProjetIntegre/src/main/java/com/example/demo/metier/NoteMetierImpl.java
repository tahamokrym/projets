package com.example.demo.metier;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.NoteRepository;
import com.example.demo.dao.PersonneRepository;
import com.example.demo.entities.Note;
import com.example.demo.entities.Personne;

@Service
@Transactional
public class NoteMetierImpl implements INoteMetier{

	@Autowired
	private NoteRepository noteRepository;
	
	@Autowired
	private PersonneRepository personneRepository;
	
	@Override
	public void AjouterNote(String objet, String description, Personne personne, String LienFichier) {
		Note n=new Note(objet,description,personne,LienFichier);
		noteRepository.save(n);
		
	}
	@Override
	public void AjouterNote(String objet, String description, Long matricule, String LienFichier) {
		Personne p = personneRepository.findOne(matricule);
		Note n=new Note(objet,description,p,LienFichier);
		noteRepository.save(n);
		
	}

	@Override
	public Page<Note> ListsExam(String objet, int page, int size) {
		return noteRepository.ListNoteByObjet(objet,new PageRequest(page, size));
	}
	
	@Override
	public Page<Note> ListsNotesRecherche(String objet, int page, int size) {
		return noteRepository.RechercherNote("%"+objet+"%",new PageRequest(page, size));
	}
	
	@Override
	public Page<Note> ListsTousLesNotes(int page, int size) {
		return noteRepository.ListTousNotes(new PageRequest(page, size));
	}

}
