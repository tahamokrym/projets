package com.example.demo.web;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.dao.MessageRepository;
import com.example.demo.dao.PersonneRepository;
import com.example.demo.entities.Message;
import com.example.demo.entities.Personne;
import com.example.demo.metier.IMessageMetier;

@Controller
public class MessageController {
	
	@Autowired
	private IMessageMetier messageMetier;
	
	@Autowired
	private MessageRepository messageRepository;
	
	@Autowired
	private PersonneRepository personneRepository;
	
	@RequestMapping("/envoyerMessage")
	public ModelAndView showEnvoiMessage() {
		return new ModelAndView("envoyerMessage");
	}
	
	
	@PostMapping("/envoyerMessage")
	public ModelAndView postEnvoiMessage(@RequestParam("objet") String objet, @RequestParam("message") String message, @RequestParam("destinataire") String destinataire, RedirectAttributes redirectAttributes) {

		
		if (destinataire.isEmpty()) {
			return new ModelAndView("envoyerMessage", "reponse", "please taper le destinataire");
		}
		
		if (objet.isEmpty()) {
			return new ModelAndView("envoyerMessage", "reponse", "please taper le destinataire");
		}
		
		if (message.isEmpty()) {
			return new ModelAndView("envoyerMessage", "reponse", "please taper le destinataire");
		}
		
		try {
			
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String matricule=auth.getName();
		messageMetier.envoyerMessage(Long.parseLong(matricule), Long.parseLong(destinataire), objet, message);
		
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("envoyerMessage", "reponse", "Message envoi sucessfully");
	}
	
	
	
	 
	/*
	 * Page<Message> messageEnvoyesPageable(Pageable pageable){ //1072L pour tester
	 * return messageMetier.listMessageEnvoyes(1072L, 0, 2); }
	 */
	  
	
	
	
	/*
	 * @RequestMapping(value= "/voirMessagesEnvoyes", method= RequestMethod.GET)
	 * public String Consulter(Model model) { try { Page<Message>
	 * MessageEnvoyes=messageMetier.listMessageEnvoyes(1072L, 0, 4);
	 * model.addAttribute("listeMessagesEnvoyes", MessageEnvoyes.getContent());
	 * 
	 * } catch(Exception e) { model.addAttribute("exception", e); } return
	 * "listeMessages"; }
	 */
	
	@RequestMapping("/listMessageEnvoye")
	public String consulter(Model model){
		
	try {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String matricule=auth.getName();
	   Page<Message> messagesEnvoyes=messageMetier.listMessageEnvoyes(Long.parseLong(matricule),0, 15);
	

	model.addAttribute("messagesEnvoyes", messagesEnvoyes.getContent());
	 // System.out.println(operations.getContent());
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "listMessagesEnvoyes";
	}
	
	
	@RequestMapping("/listMessageRecu")
	public String consulter2(Model model){
		
	try {
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String matricule=auth.getName();
	   Page<Message> messagesRecus=messageMetier.listMessageRecus(Long.parseLong(matricule),0, 15);
	
	
	model.addAttribute("messagesRecus", messagesRecus.getContent());
	 // System.out.println(operations.getContent());
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "listMessagesRecus";
	}
	

	
	
}
