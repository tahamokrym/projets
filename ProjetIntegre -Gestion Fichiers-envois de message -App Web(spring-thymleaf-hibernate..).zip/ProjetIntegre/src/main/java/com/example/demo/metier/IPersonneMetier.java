package com.example.demo.metier;

import com.example.demo.entities.Personne;

public interface IPersonneMetier {
	
	public void update(Long matricule, String username, String email, long telephone);

}
