package com.example.demo.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.dao.PersonneRepository;
import com.example.demo.entities.Message;
import com.example.demo.entities.Personne;
import com.example.demo.metier.IPersonneMetier;

@Controller
public class PersonneController {
	
	@Autowired
	private PersonneRepository personneRepository;
	
	
	@RequestMapping("/consulterPersonne")
	public String consulter(Model model,String codeCompte){
		model.addAttribute("codeCte",codeCompte);
	try {
		Personne cp=personneRepository.findOne(Long.parseLong(codeCompte));
	
	
	model.addAttribute("compte",cp);
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "findPersonne";
	}
	
	@RequestMapping("/modifierPersonne")
	public String consulter2(Model model,String username, String telephone, String email){
	try {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String matricule=auth.getName();
		Personne cp=personneRepository.findOne(Long.parseLong(matricule));
		model.addAttribute("compte",cp);
		cp.setUsername(username);
		cp.setEmail(email);
		cp.setTelephone(Long.parseLong(telephone));
		personneRepository.save(cp);
	
	
	
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "modifierPersonne";
	}

	
	

}
