package com.example.demo.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Note implements Serializable {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String objet;
	private String description;
	@ManyToOne
	@JoinColumn(name="NOTE_PERS")
	private Personne personne;
	private String LienFichier;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getObjet() {
		return objet;
	}
	public void setObjet(String objet) {
		this.objet = objet;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Personne getPersonne() {
		return personne;
	}
	public void setPersonne(Personne personne) {
		this.personne = personne;
	}
	public String getLienFichier() {
		return LienFichier;
	}
	public void setLienFichier(String lienFichier) {
		LienFichier = lienFichier;
	}
	public Note() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Note(String objet, String description, Personne personne, String lienFichier) {
		super();
		this.objet = objet;
		this.description = description;
		this.personne = personne;
		LienFichier = lienFichier;
	}

	

	
}
