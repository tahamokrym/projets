package com.example.demo.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.Note;


public interface NoteRepository extends JpaRepository<Note, Long>{
	@Query("select n from Note n where n.objet=:x  order by n.id DESC")
	public Page<Note> ListNoteByObjet(@Param("x")String objet, Pageable pageable);
	
	@Query("select n from Note n order by n.id DESC")
	public Page<Note> ListTousNotes(Pageable pageable);
	
	@Query("select n from Note n where n.description LIKE :x")
	public Page<Note> RechercherNote(@Param("x")String description, Pageable pageable);

}
