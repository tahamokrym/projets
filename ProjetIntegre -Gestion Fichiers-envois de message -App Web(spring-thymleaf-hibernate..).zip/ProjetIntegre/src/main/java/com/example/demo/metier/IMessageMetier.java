package com.example.demo.metier;

import org.springframework.data.domain.Page;

import com.example.demo.entities.Message;
import com.example.demo.entities.Personne;

public interface IMessageMetier {
	public void envoyerMessage(Long matricule1, Long matricule2, String objet, String message);
	public void envoyerMessage(Personne p1, Personne p2, String objet, String message);
	public Page<Message>listMessageEnvoyes(Long matricule, int page, int size); 
	public Page<Message>listMessageRecus(Long matricule, int page, int size); 
	
}
