package com.example.demo.metier;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.dao.MessageRepository;
import com.example.demo.dao.PersonneRepository;
import com.example.demo.entities.Personne;

public class PersonneMetierImpl implements IPersonneMetier {

	@Autowired
	private PersonneRepository personneRepository;
	public void update(Long matricule, String username, String email, long telephone) {
		Personne personne=personneRepository.findOne(matricule);
		personne.setUsername(username);
		personne.setTelephone(telephone);
		personne.setEmail(email);
		personneRepository.save(personne);
		

	}

}
