package com.example.demo.web;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.entities.Message;
import com.example.demo.entities.Note;
import com.example.demo.entities.Personne;
import com.example.demo.metier.INoteMetier;

@Controller
public class NoteController {
	public static String UPLOAD_FOLDER = "C:/test/";	
	
	//public static String UPLOAD_FOLDER = "\\resources\\uploads\\";	

	@Autowired
	private INoteMetier noteMetier;

	@RequestMapping("/ajouterNote")
	public ModelAndView showUpload() {
		return new ModelAndView("upload");
	}
	

	@PostMapping("/ajouterNote")
	public ModelAndView fileUpload(@RequestParam("file") MultipartFile file, @RequestParam("select") String select, @RequestParam("description") String description, RedirectAttributes redirectAttributes) {

		
		if (file.isEmpty()) {
			return new ModelAndView("upload", "message", "Please select a file and try again");
		}

		try {
			
			// read and write the file to the selected location-
			byte[] bytes = file.getBytes();
			Path path = Paths.get(UPLOAD_FOLDER,file.getOriginalFilename());
			Files.write(path, bytes); //ajouter le fichier au serveur
			
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String matricule=auth.getName();
			noteMetier.AjouterNote(select, description, Long.parseLong(matricule), UPLOAD_FOLDER +file.getOriginalFilename()); //ajouter à la bdd (1072L est normalement le matricule de personne deja authentifie)
			

		} catch (IOException e) {
			e.printStackTrace();
		}

		return new ModelAndView("upload", "message", "File Uploaded sucessfully");
	}
	
	
	
	
	@RequestMapping("/acceuil")
	public String consulter(Model model){
	try {
	   Page<Note> listNotes=noteMetier.ListsTousLesNotes(0, 15);

	model.addAttribute("listNotes", listNotes.getContent());
	 // System.out.println(operations.getContent());
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "acceuil";
	}
	
	
	
	
	@RequestMapping("/TableauDaffichage")
	public String consulter2(Model model,String Objet){
	try {
	   Page<Note> listNotes=noteMetier.ListsExam(Objet, 0, 15);

	model.addAttribute("listNotes", listNotes.getContent());
	 // System.out.println(operations.getContent());
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "TableauDaffichage";
	}
	
	
	@RequestMapping("/Document")
	public String consulter3(Model model){
	try {
		Page<Note> listNotes=noteMetier.ListsExam("Document", 0, 15);

	model.addAttribute("listNotes", listNotes.getContent());
	 // System.out.println(operations.getContent());
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "Document";
	}
	
	
	@RequestMapping("/Evenement")
	public String consulter4(Model model){
	try {
		Page<Note> listNotes=noteMetier.ListsExam("Evenement", 0, 15);

	model.addAttribute("listNotes", listNotes.getContent());
	 // System.out.println(operations.getContent());
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "Evenement";
	}
		
	
	@RequestMapping("/RechercheNote")
	public String consulter5(Model model,String Objet){
	try {
	   Page<Note> listNotes=noteMetier.ListsNotesRecherche(Objet, 0, 15);

	model.addAttribute("listNotes", listNotes.getContent());
	 // System.out.println(operations.getContent());
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "RechercheNotes";
	}
	
	
	@RequestMapping("/Rechercher")
	public String consulter(Model model,String objet){
		model.addAttribute("objet",objet);
	try {
	   Page<Note> resultatRecherche=noteMetier.ListsNotesRecherche(objet, 0, 15);
	model.addAttribute("resultatRecherche", resultatRecherche.getContent());
	 
	} catch (Exception e) {
	model.addAttribute("exception",e);
	}
	return "RechercheNotes";
	}
	
}
