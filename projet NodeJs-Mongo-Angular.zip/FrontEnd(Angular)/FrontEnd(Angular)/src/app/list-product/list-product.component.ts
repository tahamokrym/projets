import { Component, OnInit } from '@angular/core';
import { conditionallyCreateMapObjectLiteral } from '@angular/compiler/src/render3/view/util';
import { ProduitService } from '../services/produit.service';
import Vm from '../model/vm';

@Component({
  selector: 'app-list-product',
  templateUrl: './list-product.component.html',
  styleUrls: ['./list-product.component.css']
})
export class ListProductComponent implements OnInit {
  listeVm: Array<Vm>;
 
  


  constructor( private serviceProduct: ProduitService) { 
  }

  ngOnInit() {
    
  this.serviceProduct.getVms();
  this.listeVm= this.serviceProduct.getAll();
  }

  test(a)
  {
    alert(JSON.stringify(a))
  }
  

}
