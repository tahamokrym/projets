import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import Product from "../model/Product";
import Vm from '../model/vm';

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {

  @Input() vm: Vm;
  statutDetails: boolean=false;
  constructor() { }

  ngOnInit() {
  }




  modifierStatut(): void {
    if (this.vm.statut) {
      alert("est ce que vous etez sur");
      this.vm.statut=false;
    }
    else {
      
      this.vm.statut=true;
    }
    
  }

  detailsVm() : void {
    this.statutDetails=true;
    
    
  }

  ContredetailsVm() : void {
    this.statutDetails=false;
    
  }

  
  etat(): String {
    if (this.vm.statut) {
      return ("Démarrée");
    }
    else {
      return ("Arretée");
    }
  }

  etatButton(): String {
    if (this.vm.statut) {
      return ("Arreter");
    }
    else {
      return ("Démarrer");
    }
  }

  colorEtat(vm: Vm): Object {
    if(vm.statut==true) return {color:'green'}
    else return {color:'red'}
  }

  colorButton(vm: Vm): Object {
    if(vm.statut==true) return {color:'red'}
    else return {color:'green'}
  }



}
