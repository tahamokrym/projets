import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ListProductComponent } from './list-product/list-product.component';
import { ProductItemComponent } from './product-item/product-item.component';
import { TestComponent } from './test/test.component';
import { ProduitService } from './services/produit.service';
import {HttpClientModule} from '@angular/common/http';
import { OneVmComponent } from './one-vm/one-vm.component'

export const appRoutes: Routes = [
  {path:'vms', component:ListProductComponent},
  {path:'vms/:id', component:OneVmComponent},


]

@NgModule({
  declarations: [
    AppComponent,
    ListProductComponent,
    ProductItemComponent,
    TestComponent,
    OneVmComponent,
   
  ],
  imports: [
    BrowserModule,
    HttpClientModule,RouterModule.forRoot(
      appRoutes)
  ],
  providers: [ProduitService],
  bootstrap: [AppComponent]
})
export class AppModule { }
