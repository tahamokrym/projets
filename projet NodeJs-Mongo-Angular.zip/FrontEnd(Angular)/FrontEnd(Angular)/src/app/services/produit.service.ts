import { Injectable } from '@angular/core';
import Vm from '../model/vm';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProduitService {

  listeVm : Array<Vm>=[];

  oneVm: Array<Vm>=[];

   getVms() {
    this.http.get('http://localhost:5000/vms').subscribe((result:any[])=>{
      result.map((element:Vm) =>{
        this.listeVm.push(element);
      });

    }, (error) => console.log(error));
  }
  

  getAll() : Array<Vm> {
    console.log("listVM= "+this.listeVm)
    return this.listeVm
  } 

  getOne() : Array<Vm> {
   
    return this.oneVm
  } 

  get(id:string) {
    this.http.get('http://localhost:5000/vms/'+id).subscribe((result:any)=>{
    
        this.oneVm.push(result);
    
    }, (error) => console.log(error));
  }

  
  /* listeVm: Array<Vm> = [
    {
      id:1,
      nom: "machine vm1",
      adresseIP: "192.168.1.4",
      SystemeExploitation: "linux",
      statut: false,
      comptes:[
        { 
          login:"admin",
          role: "administrateur"
        },
        { 
          login:"mokrym",
          role: "user"
        }
      ]
    },
    {
      id:2,
      nom: "machine vm2",
      adresseIP: "192.168.1.60",
      SystemeExploitation: "windows",
      statut: true,
      comptes:[
        { 
          login:"taha",
          role: "user"
        }
      ]
    }
  ] 

  add(vm: Vm):void {
    this.listeVm.push(vm);
  }

  get(id:number):Vm {
    return this.listeVm[id]
  }

  getAll() : Array<Vm> {
    return this.listeVm
  }  */

  constructor(private http : HttpClient) {}
}
