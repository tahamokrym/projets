
export default class Vm {
    id:number;
    nom: string;
    adresseIP: string;
    SystemeExploitation: string;
    statut: boolean = false;
    comptes: Array<{login:string, role:string}>;
    
    constructor(id: number, nom: string, adresseIP: string, SystemeExploitation: string,
        statut: boolean) {

            nom = this.nom;
            adresseIP = this.adresseIP;
            SystemeExploitation = this.SystemeExploitation;
            statut = this.statut;

    }
}