import { conditionallyCreateMapObjectLiteral } from '@angular/compiler/src/render3/view/util';

export default class Product {
    id:number;
    code: string;
    name: string;
    description: string;
    prix: number;
    image: string;
    isDisponible: boolean = true;
    likeIt: number = 0;
    dislikeIt: number = 0;
 

    constructor(code: string, name: string, description: string,
        prix: number, image: string,) {

        code = this.code;
        name = this.name;
        description = this.description;
        prix = this.prix;
        image = this.image;

    }
}