export default class Compte {
    login: string;
    role: string;
 

    constructor(login: string, password: string) {

            login = this.login;
            this.role = this.role;

    }
}