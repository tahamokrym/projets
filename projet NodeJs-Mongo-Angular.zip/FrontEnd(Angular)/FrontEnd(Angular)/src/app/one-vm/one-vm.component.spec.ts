import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OneVmComponent } from './one-vm.component';

describe('OneVmComponent', () => {
  let component: OneVmComponent;
  let fixture: ComponentFixture<OneVmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OneVmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OneVmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
