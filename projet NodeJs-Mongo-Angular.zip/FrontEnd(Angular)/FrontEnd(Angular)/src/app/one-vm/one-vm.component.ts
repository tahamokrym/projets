import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProduitService } from '../services/produit.service';
import Vm from '../model/vm';
@Component({
  selector: 'app-one-vm',
  templateUrl: './one-vm.component.html',
  styleUrls: ['./one-vm.component.css']
})
export class OneVmComponent implements OnInit {

  vms: Array<Vm>;

  constructor(private serviceProduct: ProduitService, private route:ActivatedRoute) { }

  ngOnInit() {
    this.serviceProduct.get(this.route.snapshot.params['id']);
    
    this.vms=this.serviceProduct.getOne();

  }

}
