package com.example.myapplication3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ContactezNous extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactez_nous);

        Button btnEnvoie = (Button)findViewById(R.id.envoyer);
        btnEnvoie.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                EnvoiMessageRedirectToMain(v);
            }
        });
    }


    public void EnvoiMessageRedirectToMain(View v) {

        final EditText numero =(EditText)findViewById(R.id.numero);
        final EditText message = (EditText)findViewById(R.id.message);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Attention");
        builder.setMessage("Vous etez sur d'envoyer ce message");
        builder.setIcon(android.R.drawable.ic_dialog_alert);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                if(ActivityCompat.checkSelfPermission(ContactezNous.this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED) {

                    String num = numero.getText().toString();
                    String msg = message.getText().toString();
                    SmsManager.getDefault().sendTextMessage(num, null, msg, null, null);

                    Intent intent=new Intent(ContactezNous.this,MainActivity.class);
                    startActivity(intent);
                }
                else{
                    if(!ActivityCompat.shouldShowRequestPermissionRationale(ContactezNous.this,Manifest.permission.SEND_SMS)) {
                        String[] permissions= {Manifest.permission.SEND_SMS};
                        ActivityCompat.requestPermissions(ContactezNous.this,permissions,2);
                    }
                    else{
                    }
                }
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.show();
    }
}
