package com.example.myapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class choisir extends AppCompatActivity {

    private ImageView imageView;
    private Spinner spinner, spinner2;
    private Button btnSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choisir);

        imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.logo);

        addItemsOnSpinner();
        addListenerOnButton();
    }



    public void addItemsOnSpinner() {

        spinner = (Spinner) findViewById(R.id.spinner);

        RequestQueue ExampleRequestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest ExampleRequest = new JsonArrayRequest(Request.Method.GET, "http://10.72.39.193:5000/adresses", null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if (response != null) {
                    try{
                        List<String> list = new ArrayList<String>();
                        for (int i=0;i<response.length();i++)   list.add(response.getJSONObject(i).getString("name"));


                        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, list);
                        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinner.setAdapter(dataAdapter);



                    }catch(Exception e){
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }

        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
        ExampleRequestQueue.add(ExampleRequest);

    }



    public void addListenerOnButton() {

        spinner = (Spinner) findViewById(R.id.spinner);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent i= new Intent(choisir.this,reserver.class);
                i.putExtra("adresse",String.valueOf(spinner.getSelectedItem()));
                i.putExtra("nombre",String.valueOf(spinner2.getSelectedItem()));
                startActivity(i);
            }

        });
    }




    private List<String> Submit(String URL)
    {
        String url=URL;
        RequestQueue ExampleRequestQueue = Volley.newRequestQueue(getApplicationContext());
        final List<String> listdata = new ArrayList<String>();

        JsonArrayRequest ExampleRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                if (response != null) {
                    try{
                        for (int i=0;i<response.length();i++){
                            listdata.add(response.getJSONObject(i).getString("nom"));
                            Toast.makeText(getApplicationContext(),listdata.get(i).toString(),Toast.LENGTH_LONG).show();

                        }
                    }catch(Exception e){
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }
            }

        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
        ExampleRequestQueue.add(ExampleRequest);

        return listdata;
    }
}
