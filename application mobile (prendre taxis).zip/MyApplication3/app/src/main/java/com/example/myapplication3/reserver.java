package com.example.myapplication3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class reserver extends AppCompatActivity {


    private ImageView imageView;
    private Spinner spinner;
    private Button btnSubmit;
    private TextView textView6;
    private TextView textView7;
    private String taxiChoisi;
    private HashMap<Integer,String> listTaxi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserver);

        imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.logo);

        Intent i=getIntent();

        Toast.makeText(getApplicationContext(),i.getStringExtra("adresse"),Toast.LENGTH_LONG).show();
        Toast.makeText(getApplicationContext(),i.getStringExtra("nombre"),Toast.LENGTH_LONG).show();


        addItemsOnSpinner(i.getStringExtra("adresse"),i.getStringExtra("nombre"));
        clickReserver(i.getStringExtra("nombre"));
        addListenerOnSpinnerItemSelection();
    }


    public void addItemsOnSpinner(String adresse,String nombre) {

        spinner = (Spinner) findViewById(R.id.spinner3);

        RequestQueue ExampleRequestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest ExampleRequest = new JsonArrayRequest(Request.Method.GET, "http://10.72.39.193:5000/tests/"+nombre+"/"+adresse, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if (response != null) {
                    try{
                        List<String> list = new ArrayList<String>();
                        listTaxi=new HashMap<Integer, String>();

                        for (int i=0;i<response.length();i++)   {
                            list.add(response.getJSONObject(i).getString("numTaxi"));
                            listTaxi.put(Integer.parseInt(response.getJSONObject(i).getString("numTaxi")),response.getJSONObject(i).getString("numChauffeur"));
                        }

                        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, list);
                        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinner.setAdapter(dataAdapter);


                    }catch(Exception e){
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }

        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
        ExampleRequestQueue.add(ExampleRequest);

    }


    public void clickReserver(String nombre) {


        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        final int nombre2=Integer.parseInt(nombre);

        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                ButtonYesNoClick(btnSubmit,nombre2);
            }
        });
    }


    public void ButtonYesNoClick(View v,int nombre) {

        final int nombre2=nombre;
        final View view=v;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Demande de confirmation");
        builder.setMessage("Voulez vous continer ?");
        builder.setIcon(android.R.drawable.ic_dialog_alert);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                JSONObject jsonBody = new JSONObject();
                try {
                    jsonBody.put("nbPlace", nombre2);  //remplir le Json par le nombre de place
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }

                RequestQueue ExampleRequestQueue = Volley.newRequestQueue(getApplicationContext());
                JsonObjectRequest ExampleRequest = new JsonObjectRequest  (Request.Method.PUT, "http://10.72.39.193:5000/taxi/"+taxiChoisi,jsonBody,  new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                    }

                }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });
                ExampleRequestQueue.add(ExampleRequest);
                EnvoiMessageRedirectToMain(view);
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.show();
    }


    public void EnvoiMessageRedirectToMain(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Félicitation");
        builder.setMessage("Votre demande a été transférée au chauffeur");
        builder.setIcon(android.R.drawable.ic_dialog_info);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {


                if(ActivityCompat.checkSelfPermission(reserver.this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED) {
                    //faire le code qui va transferer un message au conducteur
                    String message="vous etez convocu à l'adresse suivant: ";
                    SmsManager sms = SmsManager.getDefault();
                    String numero=listTaxi.get(Integer.parseInt(taxiChoisi));
                    SmsManager.getDefault().sendTextMessage(numero, null, message, null, null);

                    Intent intent=new Intent(reserver.this,MainActivity.class);
                    startActivity(intent);
                }
                else{
                    if(!ActivityCompat.shouldShowRequestPermissionRationale(reserver.this,Manifest.permission.SEND_SMS)) {
                        String[] permissions= {Manifest.permission.SEND_SMS};
                        ActivityCompat.requestPermissions(reserver.this,permissions,2);
                    }
                    else{
                    }
                }
            }
        });
        builder.show();
    }


    public void addListenerOnSpinnerItemSelection() {
        spinner = (Spinner) findViewById(R.id.spinner3);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int pos,long id) {
                taxiChoisi=parent.getItemAtPosition(pos).toString();
                miseajour(parent.getItemAtPosition(pos).toString());
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
    }



    public void  miseajour(String choix) {

        RequestQueue ExampleRequestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest ExampleRequest = new JsonArrayRequest(Request.Method.GET, "http://10.72.39.193:5000/taxisByNum/"+choix, null, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {
                if (response != null) {
                    try{

                        textView6=(TextView)findViewById(R.id.textView6);
                        textView7=(TextView)findViewById(R.id.textView7);
                        textView6.setText("type de voiture: "+ response.getJSONObject(0).getString("typeTaxi"));
                        textView7.setText("nombre de places occupés: "+ response.getJSONObject(0).getString("nbPlace"));
                    }catch(Exception e){
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }
        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
        ExampleRequestQueue.add(ExampleRequest);

    }







}
